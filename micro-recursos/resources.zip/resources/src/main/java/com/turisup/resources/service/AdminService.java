package com.turisup.resources.service;

import com.complexible.stardog.api.Connection;
import com.complexible.stardog.jena.SDJenaFactory;
import com.turisup.resources.model.Place;
import com.turisup.resources.model.PlaceResponse;
import com.turisup.resources.model.parser.Parser;
import com.turisup.resources.model.parser.QueryOptions;
import com.turisup.resources.model.request.get.AdminPlaceRequest;
import com.turisup.resources.model.request.post.PlaceRequest;
import com.turisup.resources.repository.DBConnection;
import com.turisup.resources.repository.SparqlTemplates;
import com.turisup.resources.repository.StardogHttpQueryConn;
import org.apache.jena.query.*;
import org.apache.jena.rdf.model.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.turisup.resources.repository.SparqlTemplates.updatePlaceQuery;

@Service
public class AdminService {
    @Autowired
    PlaceService placeService;
    StardogHttpQueryConn stardogHttpQueryConn;
    public List<Place> placesByRegion(AdminPlaceRequest adminPlaceRequest){
        List<Place> places = new ArrayList<>();
        try(Connection myConnection = DBConnection.createConnection()){
            Model myModel = SDJenaFactory.createModel(myConnection);


            String queryString = SparqlTemplates.getPlacesByRegionOrgStatusUser(adminPlaceRequest);

            Query query = QueryFactory.create(queryString);
            QueryExecution qexec = QueryExecutionFactory.create(query,myModel);
            try {
                ResultSet results= qexec.execSelect();
                while(results.hasNext()){
                    QuerySolution soln = results.nextSolution();
                    //myNewPlace= Parser.QueryResult2Place(soln,true);
                   // myNewPlace.setId(placeId);
                }
            }finally {
                qexec.close();
            }
        }
        return places;
    }


    public ResponseEntity<?> updatePlace(PlaceRequest placeUpdateInfo){
        String query = updatePlaceQuery(placeUpdateInfo);
        stardogHttpQueryConn = new StardogHttpQueryConn();
        return stardogHttpQueryConn.PostToTriplestore(query);
    }

    public ResponseEntity<?> actualizarImagenesFB() {
        QueryOptions queryOptions = new QueryOptions();
        List<PlaceResponse> places = placeService.all( queryOptions);
        System.out.println(places);
        return (ResponseEntity<?>) ResponseEntity.ok();
    }
}
