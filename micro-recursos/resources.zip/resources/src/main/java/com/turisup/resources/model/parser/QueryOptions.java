package com.turisup.resources.model.parser;

import lombok.Data;

@Data
public class QueryOptions {
    String organizacionId;
    String regionId;
    String creadorId;
    String lugarId;
    String estadoLugar;
}
