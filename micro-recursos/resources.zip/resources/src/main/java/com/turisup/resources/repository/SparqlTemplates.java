package com.turisup.resources.repository;

import com.turisup.resources.model.parser.QueryOptions;
import com.turisup.resources.model.request.get.AdminPlaceRequest;
import com.turisup.resources.model.request.post.PlaceRequest;
import org.checkerframework.checker.units.qual.Prefix;

public class SparqlTemplates {

    static final String prefixes = "prefix : <http://turis-ucuenca/>"+
            "prefix rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
            "prefix org: <http://www.w3.org/TR/vocab-org/>"+
            "prefix myorg: <http://turis-ucuenca/org/>"+
            "prefix myregiones: <http://turis-ucuenca/region/>"+
            "prefix lugar: <http://turis-ucuenca/lugar/>"+
            "prefix myusers: <http://turis-ucuenca/user/>"+
            "prefix foaf: <http://xmlns.com/foaf/0.1/>"+
            "prefix tp: <http://tour-pedia.org/download/tp.owl>"+
            "prefix vcard: <http://www.w3.org/2006/vcard/ns#>"+
            "prefix geo: <http://www.opengis.net/ont/geosparql#>"+
            "prefix dc: <http://purl.org/dc/elements/1.1/>"+
            "prefix base2:<http://turis-ucuenca#>"+
            "prefix fb:<http://turis-ucuenca#>"+
            "base  <http://turis-ucuenca/>";

    public static String getPlace(String placeId){
        String lugar = "lugar:"+placeId;
            return prefixes+"" +
                    "SELECT  ?titulo ?descripcion (GROUP_CONCAT(DISTINCT ?imagenes2 ; SEPARATOR = ',') AS ?imagenes)  ?creador ?point  (GROUP_CONCAT(DISTINCT ?idFacebook ; SEPARATOR = ',') AS ?fbIDs)  WHERE{"+
                    lugar +" dc:title ?titulo."+
                    lugar +" dc:description ?descripcion."+
                    lugar +" fb:facebookId ?faceboook_id_node."+
                    lugar +" dc:creator ?creador."+
                    lugar +" vcard:hasPhoto ?imagenes2."+
                    lugar +" geo:hasGeometry ?geometry_node."+
                    "?geometry_node geo:asWKT ?point."+
                    "?faceboook_id_node ?prop ?idFacebook."+
                    "FILTER(?prop != rdf:type)"+
                    "} GROUP BY ?titulo ?descripcion ?creador ?point";
    }

    public static String getAllPlace() {
        return prefixes+"" +
                "SELECT ?id ?titulo ?descripcion (GROUP_CONCAT(DISTINCT ?imagenes2 ; SEPARATOR = ',') AS ?imagenes)  ?creador ?point  (GROUP_CONCAT(DISTINCT ?idFacebook ; SEPARATOR = ',') AS ?fbIDs)  WHERE{"+
                "?id a tp:POI."+
                "?id dc:title ?titulo."+
                "?id dc:description ?descripcion."+
                "?id fb:facebookId ?faceboook_id_node."+
                "?id dc:creator ?creador."+
                "?id vcard:hasPhoto ?imagenes2."+
                "?id geo:hasGeometry ?geometry_node."+
                "?geometry_node geo:asWKT ?point."+
                "?faceboook_id_node ?prop ?idFacebook."+
                "FILTER(?prop != rdf:type)"+
                "} GROUP BY ?id ?titulo ?descripcion ?creador ?point";
    }

    public static String getPlacesByRegionOrgStatusUser(AdminPlaceRequest props) {

        return "";
    }

    public static String defaultQuery(QueryOptions queryOptions){

        String filters ="";
        if(queryOptions.getCreadorId()!= null){
            filters = filters + "FILTER(str(?creador)= 'http://turis-ucuenca/user/"+queryOptions.getCreadorId()+"').\n";
        }if(queryOptions.getEstadoLugar()!= null){
            filters = filters +"FILTER(str(?status) = '"+queryOptions.getEstadoLugar()+"').\n";
        }if(queryOptions.getLugarId()!= null){
            filters = filters + "FILTER(str(?place)='http://turis-ucuenca/lugar/"+queryOptions.getLugarId()+"').\n";
        }if(queryOptions.getOrganizacionId()!=null){
            filters = filters +  "FILTER(str(?org)='http://turis-ucuenca/org/"+queryOptions.getOrganizacionId()+"').\n";
        }if(queryOptions.getRegionId()!=null){
            filters = filters + "FILTER(str(?region)='http://turis-ucuenca/region/"+queryOptions.getRegionId()+"').\n";
        }

        return "prefix : <http://turis-ucuenca/>"+
        "prefix org: <http://www.w3.org/TR/vocab-org/>"+
        "prefix myorg: <http://turis-ucuenca/org/>"+
        "prefix myregiones: <http://turis-ucuenca/region/>"+
        "prefix lugar: <http://turis-ucuenca/lugar/>"+
        "prefix myusers: <http://turis-ucuenca/user/>"+
        "prefix foaf: <http://xmlns.com/foaf/0.1/>"+
        "prefix tp: <http://tour-pedia.org/download/tp.owl>"+
        "prefix vcard: <http://www.w3.org/2006/vcard/ns#>"+
        "prefix geo: <http://www.opengis.net/ont/geosparql#>"+
        "prefix dc: <http://purl.org/dc/elements/1.1/>"+
        "prefix fb:<http://turis-ucuenca#>"+
        "prefix base2:<http://turis-ucuenca#>"+
        "prefix geof: <http://www.opengis.net/def/function/geosparql/>"+
        "base  <http://turis-ucuenca/>"+

        "SELECT ?org ?orgName ?region ?regionTitulo ?place ?titulo ?status ?descripcion (GROUP_CONCAT(DISTINCT ?imagenes2 ; SEPARATOR = ',') AS ?imagenes)  ?creador ?nombre ?point  (GROUP_CONCAT(DISTINCT ?idFacebook ; SEPARATOR = ',') AS ?fbIDs)"+
        "WHERE {"+
                "?region a :Region."+
                "?region dc:title ?regionTitulo."+
                "?region geo:hasGeometry ?geoRegion."+
                "?region :isAdminBy ?org."+
                "?geoRegion geo:asWKT ?regionWKT ."+
                "?org dc:title ?orgName."+
                "?place a tp:POI ."+
                "?place dc:title ?titulo."+
                "?place dc:description ?descripcion."+
                "?place fb:facebookId ?faceboook_id_node."+
                "?place dc:creator ?creador."+
                "?place vcard:hasPhoto ?imagenes2."+
                "?place base2:status ?status."+
                "?place geo:hasGeometry ?geom."+

                "?creador foaf:name ?nombre."+

                "?faceboook_id_node ?prop ?idFacebook."+
                "?geom geo:asWKT ?point ."+

                "FILTER geof:within(?point,?regionWKT)."+
                filters+

        "} GROUP BY ?org ?orgName ?region ?regionTitulo ?place ?titulo ?status ?descripcion ?creador ?point ?nombre";
    }

    public static  String updatePlaceQuery(PlaceRequest placeUpdateInfo){
        String placeid = "'http://turis-ucuenca/lugar/"+placeUpdateInfo.getPlaceid()+"'";
        return prefixes

                +"DELETE{"
    +"?place dc:title ?titulo;"
           + "dc:description ?descripcion;"
           + "base2:status ?status;"
           + "rdfs:label ?titulo2;"
       + "}"
       + "INSERT{"
        +    "lugar:"+placeUpdateInfo.getPlaceid()+" dc:title '"+ placeUpdateInfo.getNombre()+"';"
        +    "dc:description '"+placeUpdateInfo.getDescripcion()+"';"
       +     "base2:status '"+placeUpdateInfo.getEstado()+"';"
       +     "rdfs:label '"+placeUpdateInfo.getNombre()+"'."
       + "}"
        +"WHERE{"
   +"?place dc:title ?titulo;"
         +   "dc:description ?descripcion;"
        +    "base2:status ?status;"
        +    "rdfs:label ?titulo2;"
       +     "FILTER(str(?place) = "+placeid+")"
      +  "}";
    }
}
