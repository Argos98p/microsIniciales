package com.turisup.resources.model.fb;

import lombok.Data;

@Data
public class Photo {
    String id;
}
