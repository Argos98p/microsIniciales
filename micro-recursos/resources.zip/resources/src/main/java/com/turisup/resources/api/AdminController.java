package com.turisup.resources.api;

import com.turisup.resources.model.Place;
import com.turisup.resources.model.parser.QueryOptions;
import com.turisup.resources.model.request.get.AdminPlaceRequest;
import com.turisup.resources.model.request.post.PlaceRequest;
import com.turisup.resources.service.AdminService;
import com.turisup.resources.service.PlaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    PlaceService placeService;

    @Autowired
    AdminService adminService;

    @PostMapping("actualizar")
    public ResponseEntity<?> updatePlace(@RequestBody PlaceRequest placeUpdateInfo) {
        if(placeUpdateInfo.getEstado()==null || placeUpdateInfo.getPlaceid()==null){
            return (ResponseEntity<?>) ResponseEntity.badRequest();
        }
        return adminService.updatePlace(placeUpdateInfo);
    }

    @PostMapping("actualizar-imagenes")
    public ResponseEntity<?> actualizarImagenesFb(){

        return adminService.actualizarImagenesFB();
    }
    /*
    @GetMapping("/todos")
    public ResponseEntity<List<Place>> allPlacesByRegion(@RequestBody AdminPlaceRequest adminPlaceRequest){
        List<Place> places = placeService.all();
        return ResponseEntity.ok().body(places);
    }*/
}
